<div class="content">
	<form action="" method="post" enctype="multipart/form-data">
		<div class="toolbar">
			<h2><?=$page_heading?? ''?></h2>
		</div>
		<div class="container">
			<div class="row">
				<div class="col s12">
					content
				</div>
			</div>
		</div>
	</form>
</div>

