
<header>
    <ul id="nav-mobile" class="sidenav sidenav-fixed">
                    <li><a href="home" class="<?=(($args && $args['active_link'] == 'home')? 'active' : '')?>"><i class="material-icons">home</i> Home</a></li>
                    <li><a href="category" class="<?=(($args && $args['active_link'] == 'category')? 'active' : '')?>">Categoties</a></li>
                    <li><a href="tutorial" class="<?=(($args && $args['active_link'] == 'category')? 'active' : '')?>">Tutorial</a></li>
    </ul>
    
    
    
    <div class="navbar-fixed">
        <nav class="navbar top-menu light-blue darken-2">
            <div class="nav-wrapper"><a href="#!" class="brand-logo grey-text text-darken-4">Tutorials</a>
                <ul id="top-nav" class="right">
    
                    <li><a class='dropdown-trigger' href='#' data-target='dropdown1'><i class="material-icons">settings</i></a></li>
                </ul>
                
        </nav>
    </div>
    <ul id='dropdown1' class='dropdown-content'>
         <li><a href="#"><i class="material-icons">face</i>user</a></li>
        <li><a href="logout.php" class="">Logout</a></li>

    </ul>
</header>

	<div class="main">
